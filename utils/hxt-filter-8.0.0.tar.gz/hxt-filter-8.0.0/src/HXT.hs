module HXT
where

import Text.XML.HXT.DOM    as DOM ()
import Text.XML.HXT.Parser as P()

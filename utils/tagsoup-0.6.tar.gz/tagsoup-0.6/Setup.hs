#!/usr/bin/runhaskell
import Distribution.Simple
main = defaultMain

module PPfeInstances where

import FreeNamesProp()
import ScopeNamesProp()
import NameMapsProp()
import MapDeclMProp() -- needed for removing pattern bindings.
import TiProp()
import RemoveListCompProp()
import ReAssocProp()

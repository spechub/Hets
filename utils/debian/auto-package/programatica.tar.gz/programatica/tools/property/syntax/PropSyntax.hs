
module PropSyntax (module P) where

import PropSyntaxStruct as P
import PropSyntaxRec as P

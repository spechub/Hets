main = interact (show.sum.map read.lines)

module Trace(trace) where
import Debug.Trace(trace)

module A where

infixl 6 +

a+b = undefined

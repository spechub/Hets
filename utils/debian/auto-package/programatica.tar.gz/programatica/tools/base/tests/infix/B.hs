module B(module A,module B) where
import A
infixl 7 *
infixr 8 ^

a*b = undefined
a^b = undefined

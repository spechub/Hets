module Defaults where

default(Int)

--f :: b -> (b,String)
f x = (x,show (1+read "2"))

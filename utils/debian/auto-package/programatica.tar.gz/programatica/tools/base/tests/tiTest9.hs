module Prelude where

data Int
data Bool = False|True

--f x = (x::Int,x::Bool)

g = \ x->x::Int

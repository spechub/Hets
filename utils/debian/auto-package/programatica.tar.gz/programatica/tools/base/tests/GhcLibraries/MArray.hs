module MArray where

--writeArray::
--readArray::
--newArray :: 
writeArray=undefined
readArray=undefined
newArray=undefined
bounds=undefined -- same as Array.bounds?

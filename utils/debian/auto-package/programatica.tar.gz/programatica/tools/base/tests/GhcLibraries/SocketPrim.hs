module SocketPrim where

--accept::
--socketToHandle::

accept = undefined
socketToHandle = undefined

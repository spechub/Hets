module TiLit where

fac 0 = 1
fac n = n*fac(n-1)

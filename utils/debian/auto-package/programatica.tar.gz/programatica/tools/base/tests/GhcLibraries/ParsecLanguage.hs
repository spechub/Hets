-- Dummy ParsecToken module
module ParsecLanguage where

import ParsecToken

haskellDef :: LanguageDef st
haskellDef = undefined

haskellStyle :: LanguageDef st
haskellStyle = undefined

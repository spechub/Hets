module Lit where

c = '\''
s = "as\""

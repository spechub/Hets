module TiAmbig where


--f x = show (read x)

g = show . read


four = 4

y = case undefined of 1 -> True

-- $Id: BaseTypeCheck.hs,v 1.1 2000-12-08 02:21:03 moran Exp $

module BaseTypeCheck(module BaseTypeCheckStruct,
		     module BaseTypeCheckRec)
where

import BaseTypeCheckStruct
import BaseTypeCheckRec

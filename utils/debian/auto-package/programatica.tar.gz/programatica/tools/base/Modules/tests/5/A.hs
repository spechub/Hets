module A (A.f) where
import B as A

class C where
    f :: a -> a



module A (B.f) where

import A as B

f = f

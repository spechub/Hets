module A (T(..))  where

data T = T

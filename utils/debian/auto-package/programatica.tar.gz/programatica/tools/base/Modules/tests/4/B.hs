module B where 

import A(T)

g = T

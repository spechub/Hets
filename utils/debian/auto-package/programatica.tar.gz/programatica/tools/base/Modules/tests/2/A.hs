module A (B.f) where

import A as B
import B

f = f

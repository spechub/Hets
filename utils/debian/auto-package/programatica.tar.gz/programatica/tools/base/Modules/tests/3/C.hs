module C where

f = f

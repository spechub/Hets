module A (module A) where

f = f

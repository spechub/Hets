module B (f) where
f = f

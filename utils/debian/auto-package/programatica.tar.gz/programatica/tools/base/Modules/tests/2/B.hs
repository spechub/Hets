module B where 

f = f

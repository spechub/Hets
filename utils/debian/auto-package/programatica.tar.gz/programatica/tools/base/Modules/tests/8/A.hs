module A where
import B

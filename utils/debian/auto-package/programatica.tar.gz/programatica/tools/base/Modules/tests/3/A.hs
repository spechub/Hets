module A (module B) where

import qualified B
import C

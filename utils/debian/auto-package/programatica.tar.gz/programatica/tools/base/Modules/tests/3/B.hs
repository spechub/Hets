module B(f) where
import C

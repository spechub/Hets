-- A module to make it ease to switch between the new and the old version
-- of TiMonad.
module TiMonad(module T) where
import OrigTiMonad as T
--import NewTiMonad as T

module Control_Monad_Fix (module Control.Monad.Fix) where
import Control.Monad.Fix

module A where

~(Just x) = Nothing


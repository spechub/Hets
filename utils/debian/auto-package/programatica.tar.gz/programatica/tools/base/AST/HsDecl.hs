
module HsDecl(module D) where

import HsDeclStruct as D
import HsDeclPretty as D
import HsDeclMaps as D
import HsDeclUtil as D

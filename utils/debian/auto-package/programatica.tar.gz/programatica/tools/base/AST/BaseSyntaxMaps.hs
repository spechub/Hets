module BaseSyntaxMaps(module Maps) where
import HsDeclMaps   as Maps
import HsExpMaps    as Maps
import HsFieldsMaps as Maps
import HsGuardsMaps as Maps
import HsKindMaps   as Maps
import HsPatMaps    as Maps
import HsTypeMaps   as Maps

module BaseSyntaxStruct(module Struct) where
import HsDeclStruct   as Struct
import HsExpStruct    as Struct
import HsFieldsStruct as Struct
import HsGuardsStruct as Struct
import HsKindStruct   as Struct
import HsPatStruct    as Struct
import HsTypeStruct   as Struct
import HsAssocStruct  as Struct

--import HsModule       as Struct
--import HsName	      as Struct(ModuleName(..))

import HsLiteral      as Struct
import HsIdent        as Struct
